using System.Collections;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerManager : NetworkSingleton<PlayerManager>
{
    private bool _isDisconnecting = false;

    protected override void OnSingletonAwake()
    {
    }

    private void Start()
    {
        NetworkManager.Singleton.OnClientConnectedCallback += OnClientConnected;
        NetworkManager.Singleton.OnClientDisconnectCallback += OnClientDisconnected;
        NetworkManager.Singleton.OnServerStopped += OnServerStopped;

        DontDestroyOnLoad(gameObject);
    }

    private void OnClientConnected(ulong clientId)
    {
        if (IsServer)
            SendAllPlayersDataToNewClient(clientId);
    }

    private void OnClientDisconnected(ulong clientId)
    {
        if (NetworkManager.Singleton == null || NetworkManager.Singleton.ShutdownInProgress)
            return;

        if (!IsServer)
            return;

        if (clientId == NetworkManager.Singleton.LocalClientId)
        {
            Disconnect();
            return;
        }

        PlayerIdentity[] allPlayers = FindObjectsByType<PlayerIdentity>(FindObjectsSortMode.None);
        PlayerIdentity disconnectedPlayer = System.Array.Find(allPlayers, p => p.OwnerClientId == clientId);

        // Temporary diagnostic: I haven't verified whether NGO destroys the leaving player's
        // objects BEFORE or AFTER firing this callback. If this prints false, the identity is
        // already gone and the character has to be found another way.
        Debug.Log($"[PlayerManager] Client {clientId} left. PlayerIdentity still found: {disconnectedPlayer != null}");

        if (disconnectedPlayer != null)
            disconnectedPlayer.ReleaseCharacter();

        // Removed: DisconnectClient(clientId) (the client is already gone when this callback
        // fires) and the "ConnectedClientsList.Count == 0" shutdown (the host is in that list,
        // so it could never reach 0 while the host is running).
    }

    public void Disconnect()
    {
        if (_isDisconnecting)
            return;

        _isDisconnecting = true;
        StartCoroutine(DisconnectRoutine());
    }

    private IEnumerator DisconnectRoutine()
    {
        if (NetworkManager.Singleton != null &&
            (NetworkManager.Singleton.IsHost || NetworkManager.Singleton.IsClient))
        {
            NetworkManager.Singleton.Shutdown();
        }

        yield return null;

        if (NetworkManager.Singleton != null)
            Destroy(NetworkManager.Singleton.gameObject);

        if (PlayerIdentity.LocalPlayer != null)
            Destroy(PlayerIdentity.LocalPlayer.gameObject);

        if (MenuController.Instance != null)
            Destroy(MenuController.Instance.gameObject);

        SceneManager.LoadScene("Main Menu");

        Destroy(gameObject);
    }

    private void OnServerStopped(bool stop)
    {
        NetworkManager.Singleton.OnServerStopped            -= OnServerStopped;
        NetworkManager.Singleton.OnClientConnectedCallback  -= OnClientConnected;
        NetworkManager.Singleton.OnClientDisconnectCallback -= OnClientDisconnected;
    }

    private void SendAllPlayersDataToNewClient(ulong newClientId)
    {
        PlayerIdentity[] players = FindObjectsByType<PlayerIdentity>(FindObjectsSortMode.None);

        foreach (var player in players)
        {
            if (player.Data == null || player.Cursor == null)
                continue;
            player.SendDataToNewClient(newClientId);
        }
    }
}
